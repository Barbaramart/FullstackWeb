package poo1;

public class Tienda {
	
	public void bienvenida() {
		System.out.println("Bienvenido a nuestra tienda");
	}

}
