package com.fran.xml.entidades;

public enum NivelCatalan {
	ALTO, MEDIO, BAJO
}
