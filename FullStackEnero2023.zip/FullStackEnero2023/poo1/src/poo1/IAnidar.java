package poo1;

public interface IAnidar {
	int pollitos(String nombre);
}
