package com.fran.xml.entidades;

public class CuentaSabadell {
	private NivelCatalan nivelCatalan;

	public NivelCatalan getNivelCatalan() {
		return nivelCatalan;
	}

	public void setNivelCatalan(NivelCatalan nivelCatalan) {
		this.nivelCatalan = nivelCatalan;
	}
	
}
