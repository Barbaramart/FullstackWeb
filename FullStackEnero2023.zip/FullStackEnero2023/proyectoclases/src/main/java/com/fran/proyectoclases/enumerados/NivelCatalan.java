package com.fran.proyectoclases.enumerados;

public enum NivelCatalan {
	Bajo, Medio, Alto
}
