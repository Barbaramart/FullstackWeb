package com.fran.proyectoclases.entidades;

import com.fran.proyectoclases.enumerados.NivelCatalan;

public final class CuentaSabadell extends Cuenta {

	private NivelCatalan nivelCatalan;
	
}
