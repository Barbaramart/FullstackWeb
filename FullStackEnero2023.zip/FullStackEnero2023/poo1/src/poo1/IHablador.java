package poo1;

public interface IHablador {
	void hablar();
	void gritar();
}
